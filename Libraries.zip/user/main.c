#include "nemo.h"
#include "stm32f10x_systick.h"

int stateScreen = SCR_MAIN;

int main(void)
{
  configure();
  
  //RCC_ClocksTypeDef RCC_Clocks;
  //RCC_GetClocksFreq(&RCC_Clocks);
  
  //SysTick_Config(RCC_Clocks.HCLK_Frequency / 1000);
  SysTick_SetReload(72000);
  SysTick_ITConfig(ENABLE);

  LCD_Init();
  LCD_Clear(WHITE);

  mainScreen(SCREEN_DISPLAY);

  while (1)
  {
    bgmStart();
  }
}