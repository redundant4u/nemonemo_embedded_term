#include "nemo.h"
#include "stm32f10x_systick.h"

#define NOP_1   asm volatile("NOP")
#define NOP_2   NOP_1; NOP_1
#define NOP_4   NOP_2; NOP_2
#define NOP_10  NOP_4; NOP_4; NOP_2
#define NOP_20  NOP_10; NOP_10
#define NOP_40  NOP_20; NOP_20

extern int stateScreen;

volatile uint32_t TimingDelay;

void screenDelay(void)
{
  //RCC_ClocksTypeDef RCC_Clocks;
  //RCC_GetClocksFreq(&RCC_Clocks);
  SysTick_CounterCmd(SysTick_Counter_Enable);
  
  TimingDelay = 5;
  while(TimingDelay != 0);
  
  SysTick_CounterCmd(SysTick_Counter_Disable);
  SysTick_CounterCmd(SysTick_Counter_Clear);
}

void TimingDelay_Decrement(void)
{
  if (TimingDelay != 0x00)
  {
    TimingDelay--;
  }
}

void backScreen(uint32_t EXTI_Line, GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin)
{
    if (EXTI_GetITStatus(EXTI_Line) != RESET)
    {
        if (GPIO_ReadInputDataBit(GPIOx, GPIO_Pin) == Bit_RESET)
        {
            switch (stateScreen)
            {
            case SCR_MAIN:
                break;
            case SCR_PAGE:
                stageScreen(SCREEN_CLEAR);
                mainScreen(SCREEN_DISPLAY);
                stateScreen--;
                break;
            case SCR_GAME:
                // gameScreen(SCREEN_CLEAR);
                stageScreen(SCREEN_DISPLAY);
                stateScreen--;
                break;
            }
        }
        EXTI_ClearITPendingBit(EXTI_Line);
    }
}