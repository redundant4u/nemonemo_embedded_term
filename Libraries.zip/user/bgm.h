#define REST      0
#define DO        191
#define DO_SHARP  180
#define RE        170
#define RE_SHARP  161
#define MI        152
#define PA        143
#define PA_SHARP  135
#define SOL       128
#define SOL_SHARP 120
#define RA        114
#define RA_SHARP  107
#define SI        101
#define HIGH_DO   96
#define HIGH_RE   89

#define SHORT     1
#define LONG      2

void bgmStart(void);